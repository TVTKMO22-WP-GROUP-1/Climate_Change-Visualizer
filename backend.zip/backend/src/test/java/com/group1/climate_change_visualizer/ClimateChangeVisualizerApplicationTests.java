package com.group1.climate_change_visualizer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClimateChangeVisualizerApplicationTests {

	@Test
	void contextLoads() {
	}

}
