const server = require('../backend/server');
server.start();